"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DeactivateUserResponse = void 0;
class DeactivateUserResponse {
    leaveEntitlementForThisYear;
    constructor(leaveEntitlementForThisYear) {
        this.leaveEntitlementForThisYear = leaveEntitlementForThisYear;
    }
}
exports.DeactivateUserResponse = DeactivateUserResponse;
//# sourceMappingURL=deactivateuser.response.js.map