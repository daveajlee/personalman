import { UserResponse } from './user.response';
export declare class UsersResponse {
    count: number;
    userResponses: UserResponse[];
    constructor(count: number, userResponses: UserResponse[]);
}
