export declare class LoginResponse {
    private errorMessage;
    private token;
    constructor(errorMessage: string, token: string);
}
