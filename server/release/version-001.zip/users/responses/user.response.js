"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserResponse = void 0;
const swagger_1 = require("@nestjs/swagger");
const userhistory_response_1 = require("./userhistory.response");
class UserResponse {
    firstName;
    surname;
    username;
    company;
    leaveEntitlementPerYear;
    workingDays;
    position;
    startDate;
    endDate;
    role;
    dateOfBirth;
    hourlyWage;
    contractedHoursPerWeek;
    trainings;
    userHistory;
    constructor(firstName, surname, username, company, leaveEntitlementPerYear, workingDays, position, startDate, endDate, role, dateOfBirth, hourlyWage, contractedHoursPerWeek, trainings, userHistory) {
        this.firstName = firstName;
        this.surname = surname;
        this.username = username;
        this.company = company;
        this.leaveEntitlementPerYear = leaveEntitlementPerYear;
        this.workingDays = workingDays;
        this.position = position;
        this.startDate = startDate;
        this.endDate = endDate;
        this.role = role;
        this.dateOfBirth = dateOfBirth;
        this.hourlyWage = hourlyWage;
        this.contractedHoursPerWeek = contractedHoursPerWeek;
        this.trainings = trainings;
        this.userHistory = userHistory;
    }
}
exports.UserResponse = UserResponse;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserResponse.prototype, "firstName", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserResponse.prototype, "surname", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserResponse.prototype, "username", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserResponse.prototype, "company", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], UserResponse.prototype, "leaveEntitlementPerYear", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserResponse.prototype, "workingDays", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserResponse.prototype, "position", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserResponse.prototype, "startDate", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserResponse.prototype, "endDate", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserResponse.prototype, "role", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserResponse.prototype, "dateOfBirth", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], UserResponse.prototype, "hourlyWage", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], UserResponse.prototype, "contractedHoursPerWeek", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Array)
], UserResponse.prototype, "trainings", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [userhistory_response_1.UserHistoryResponse] }),
    __metadata("design:type", Array)
], UserResponse.prototype, "userHistory", void 0);
//# sourceMappingURL=user.response.js.map