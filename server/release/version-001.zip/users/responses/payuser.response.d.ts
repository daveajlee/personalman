export declare class PayUserResponse {
    userName: string;
    amount: number;
    constructor(userName: string, amount: number);
}
