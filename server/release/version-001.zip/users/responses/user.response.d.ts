import { UserHistoryResponse } from './userhistory.response';
export declare class UserResponse {
    firstName: string;
    surname: string;
    username: string;
    company: string;
    leaveEntitlementPerYear: number;
    workingDays: string;
    position: string;
    startDate: string;
    endDate: string;
    role: string;
    dateOfBirth: string;
    hourlyWage: number;
    contractedHoursPerWeek: number;
    trainings: string[];
    userHistory: UserHistoryResponse[];
    constructor(firstName: string, surname: string, username: string, company: string, leaveEntitlementPerYear: number, workingDays: string, position: string, startDate: string, endDate: string, role: string, dateOfBirth: string, hourlyWage: number, contractedHoursPerWeek: number, trainings: string[], userHistory: UserHistoryResponse[]);
}
