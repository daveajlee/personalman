import { PayUserResponse } from "./payuser.response";
export declare class PayUsersResponse {
    employeePayTable: PayUserResponse[];
    totalSum: number;
    constructor(employeePayTable: PayUserResponse[], totalSum: number);
}
