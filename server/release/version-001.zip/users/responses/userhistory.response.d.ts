export declare class UserHistoryResponse {
    date: string;
    userHistoryReason: string;
    comment: string;
    constructor(date: string, userHistoryReason: string, comment: string);
}
