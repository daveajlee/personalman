export declare class DeactivateUserResponse {
    private leaveEntitlementForThisYear;
    constructor(leaveEntitlementForThisYear: number);
}
