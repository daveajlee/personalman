"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserUtils = void 0;
const user_model_1 = require("../models/user.model");
const user_response_1 = require("../responses/user.response");
const userhistory_response_1 = require("../responses/userhistory.response");
const userhistoryreason_enum_1 = require("../models/userhistoryreason.enum");
class UserUtils {
    static convertUserRequestToUser(userRequest, startDate, dateOfBirth) {
        return new user_model_1.User(userRequest.getFirstName(), userRequest.getSurname(), userRequest.getLeaveEntitlementPerYear(), userRequest.getPosition(), startDate, userRequest.getUsername(), userRequest.getPassword(), userRequest.getCompany(), userRequest.getWorkingDays(), userRequest.getRole(), dateOfBirth, 'ACTIVE');
    }
    static convertUserToUserResponse(user) {
        return new user_response_1.UserResponse(user["firstName"], user["lastName"], user["userName"], user["company"], user["leaveEntitlementPerYear"], user["workingDays"].join(","), user["position"], user["startDate"], user["endDate"], user["role"], user["dateOfBirth"], user["hourlyWage"], user["contractedHoursPerWeek"], user["trainingsList"], UserUtils.convertToUserHistoryResponse(user["userEntryHistoryList"]));
    }
    static convertToUserHistoryResponse(userHistoryEntryList) {
        let userHistoryResponses = [];
        if (userHistoryEntryList == null) {
            return userHistoryResponses;
        }
        userHistoryEntryList.forEach(userHistoryEntry => {
            userHistoryResponses.push(new userhistory_response_1.UserHistoryResponse(userHistoryEntry.getDate().toDateString(), userHistoryEntry.getComment(), userHistoryEntry.getUserHistoryReason()));
        });
        return userHistoryResponses;
    }
    static userHistoryReasonFromString(userHistoryReason) {
        switch (userHistoryReason) {
            case "Joined":
                return userhistoryreason_enum_1.UserHistoryReason.JOINED;
            case "Paid":
                return userhistoryreason_enum_1.UserHistoryReason.PAID;
            case "Evaluated":
                return userhistoryreason_enum_1.UserHistoryReason.EVALUATED;
            case "Warned":
                return userhistoryreason_enum_1.UserHistoryReason.WARNED;
            case "Resigned":
                return userhistoryreason_enum_1.UserHistoryReason.RESIGNED;
            case "Sacked":
                return userhistoryreason_enum_1.UserHistoryReason.SACKED;
            default:
                return null;
        }
    }
}
exports.UserUtils = UserUtils;
//# sourceMappingURL=user.utils.js.map