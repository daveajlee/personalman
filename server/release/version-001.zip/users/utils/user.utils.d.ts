import { User } from "../models/user.model";
import { UserRequest } from "../requests/user.request";
import { UserResponse } from "../responses/user.response";
import { UserHistoryResponse } from "../responses/userhistory.response";
import { UserHistoryEntry } from "../models/userhistory.entry";
import { UserHistoryReason } from "../models/userhistoryreason.enum";
export declare class UserUtils {
    static convertUserRequestToUser(userRequest: UserRequest, startDate: Date, dateOfBirth: Date): User;
    static convertUserToUserResponse(user: any): UserResponse;
    static convertToUserHistoryResponse(userHistoryEntryList: UserHistoryEntry[]): UserHistoryResponse[];
    static userHistoryReasonFromString(userHistoryReason: string): UserHistoryReason | null;
}
