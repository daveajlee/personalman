import { PaidUserRequest } from './requests/paiduser.request';
import type { Response } from 'express';
import { UsersService } from './users.service';
export declare class UsersController {
    private readonly userService;
    constructor(userService: UsersService);
    markUsersPaid(paidUserRequest: PaidUserRequest, res: Response): Promise<void>;
    processPaidUser(username: any, paidUserRequest: any): Promise<boolean>;
    payUsers(company: string, token: string, startDate: string, endDate: string, res: Response): Promise<void>;
    convertToDate(date: string): Date;
    addZeroPrefix(checkNumber: number): string;
    findAllUsers(company: string, token: string, res: Response): Promise<void>;
}
