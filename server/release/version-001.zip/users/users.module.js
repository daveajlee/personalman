"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersModule = void 0;
const common_1 = require("@nestjs/common");
const users_service_1 = require("./users.service");
const users_controller_1 = require("./users.controller");
const user_controller_1 = require("./user.controller");
const config_1 = require("@nestjs/config");
const config_2 = require("@nestjs/config");
const mongoose_1 = require("@nestjs/mongoose");
const user_model_1 = require("./models/user.model");
const user_schema_1 = require("./user.schema");
const company_module_1 = require("../company/company.module");
let UsersModule = class UsersModule {
};
exports.UsersModule = UsersModule;
exports.UsersModule = UsersModule = __decorate([
    (0, common_1.Module)({
        imports: [config_1.ConfigModule.forRoot({
                isGlobal: true,
                envFilePath: `.env`,
            }), mongoose_1.MongooseModule.forFeature([{ name: user_model_1.User.name, schema: user_schema_1.UserSchema }]), company_module_1.CompanyModule],
        providers: [users_service_1.UsersService, config_2.ConfigService],
        controllers: [users_controller_1.UsersController, user_controller_1.UserController],
        exports: [users_service_1.UsersService]
    })
], UsersModule);
//# sourceMappingURL=users.module.js.map