"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateSalaryRequest = void 0;
const swagger_1 = require("@nestjs/swagger");
class UpdateSalaryRequest {
    company;
    username;
    token;
    hourlyWage;
    contractedHoursPerWeek;
    getCompany() {
        return this.company;
    }
    getUsername() {
        return this.username;
    }
    getToken() {
        return this.token;
    }
    getHourlyWage() {
        return this.hourlyWage;
    }
    getContractedHoursPerWeek() {
        return this.contractedHoursPerWeek;
    }
}
exports.UpdateSalaryRequest = UpdateSalaryRequest;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UpdateSalaryRequest.prototype, "company", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UpdateSalaryRequest.prototype, "username", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UpdateSalaryRequest.prototype, "token", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], UpdateSalaryRequest.prototype, "hourlyWage", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], UpdateSalaryRequest.prototype, "contractedHoursPerWeek", void 0);
//# sourceMappingURL=updatesalary.request.js.map