export declare class AddTrainingRequest {
    private company;
    private username;
    private token;
    private trainingCourse;
    getCompany(): string;
    getUsername(): string;
    getToken(): string;
    getTrainingCourse(): string;
}
