"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddTimesheetHoursRequest = void 0;
const swagger_1 = require("@nestjs/swagger");
class AddTimesheetHoursRequest {
    company;
    username;
    token;
    date;
    hours;
    getCompany() {
        return this.company;
    }
    getUsername() {
        return this.username;
    }
    getToken() {
        return this.token;
    }
    getHours() {
        return this.hours;
    }
    getDate() {
        return this.date;
    }
}
exports.AddTimesheetHoursRequest = AddTimesheetHoursRequest;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], AddTimesheetHoursRequest.prototype, "company", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], AddTimesheetHoursRequest.prototype, "username", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], AddTimesheetHoursRequest.prototype, "token", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], AddTimesheetHoursRequest.prototype, "date", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], AddTimesheetHoursRequest.prototype, "hours", void 0);
//# sourceMappingURL=addtimesheethours.request.js.map