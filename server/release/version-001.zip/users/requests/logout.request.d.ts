export declare class LogoutRequest {
    private token;
    constructor(token: string);
    getToken(): string;
}
