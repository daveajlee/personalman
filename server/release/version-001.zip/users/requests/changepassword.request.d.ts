export declare class ChangePasswordRequest {
    private company;
    private username;
    private token;
    private currentPassword;
    private newPassword;
    getCompany(): string;
    getUsername(): string;
    getToken(): string;
    getCurrentPassword(): string;
    getNewPassword(): string;
}
