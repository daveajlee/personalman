export declare class UserRequest {
    firstName: string;
    surname: string;
    username: string;
    password: string;
    company: string;
    leaveEntitlementPerYear: number;
    workingDays: string;
    position: string;
    startDate: string;
    role: string;
    dateOfBirth: string;
    setLeaveEntitlementPerYear(leaveEntitlementPerYear: number): void;
    getDateOfBirth(): string;
    getRole(): string;
    getWorkingDays(): string;
    getCompany(): string;
    getPassword(): string;
    getUsername(): string;
    getPosition(): string;
    getLeaveEntitlementPerYear(): number;
    getSurname(): string;
    getFirstName(): string;
    getStartDate(): string;
}
