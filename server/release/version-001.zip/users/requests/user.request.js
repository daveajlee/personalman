"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserRequest = void 0;
const swagger_1 = require("@nestjs/swagger");
class UserRequest {
    firstName;
    surname;
    username;
    password;
    company;
    leaveEntitlementPerYear;
    workingDays;
    position;
    startDate;
    role;
    dateOfBirth;
    setLeaveEntitlementPerYear(leaveEntitlementPerYear) {
        this.leaveEntitlementPerYear = leaveEntitlementPerYear;
    }
    getDateOfBirth() {
        return this.dateOfBirth;
    }
    getRole() {
        return this.role;
    }
    getWorkingDays() {
        return this.workingDays;
    }
    getCompany() {
        return this.company;
    }
    getPassword() {
        return this.password;
    }
    getUsername() {
        return this.username;
    }
    getPosition() {
        return this.position;
    }
    getLeaveEntitlementPerYear() {
        return this.leaveEntitlementPerYear;
    }
    getSurname() {
        return this.surname;
    }
    getFirstName() {
        return this.firstName;
    }
    getStartDate() {
        return this.startDate;
    }
}
exports.UserRequest = UserRequest;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserRequest.prototype, "firstName", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserRequest.prototype, "surname", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserRequest.prototype, "username", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserRequest.prototype, "password", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserRequest.prototype, "company", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], UserRequest.prototype, "leaveEntitlementPerYear", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserRequest.prototype, "workingDays", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserRequest.prototype, "position", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserRequest.prototype, "startDate", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserRequest.prototype, "role", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], UserRequest.prototype, "dateOfBirth", void 0);
//# sourceMappingURL=user.request.js.map