export declare class AddTimesheetHoursRequest {
    private company;
    private username;
    private token;
    private date;
    private hours;
    getCompany(): string;
    getUsername(): string;
    getToken(): string;
    getHours(): number;
    getDate(): string;
}
