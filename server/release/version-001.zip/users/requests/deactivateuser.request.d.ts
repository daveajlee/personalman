export declare class DeactivateUserRequest {
    private company;
    private username;
    private token;
    private resigned;
    private leavingDate;
    private reason;
    getReason(): string;
    isResigned(): boolean;
    getLeavingDate(): string;
    getCompany(): string;
    getUsername(): string;
    getToken(): string;
}
