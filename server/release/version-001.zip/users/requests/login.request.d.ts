export declare class LoginRequest {
    private company;
    private username;
    private password;
    constructor(company: string, username: string, password: string);
    getCompany(): string;
    getUsername(): string;
    getPassword(): string;
}
