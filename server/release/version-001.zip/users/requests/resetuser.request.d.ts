export declare class ResetUserRequest {
    private company;
    private username;
    private password;
    private token;
    getCompany(): string;
    getToken(): string;
    getUsername(): string;
    getPassword(): string;
}
