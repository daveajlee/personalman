export declare class PaidUserRequest {
    company: string;
    employeePayTable: [];
    startDate: string;
    endDate: string;
    token: string;
    constructor(company: string, employeePayTable: [], startDate: string, endDate: string, token: string);
}
