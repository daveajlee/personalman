export declare class UpdateSalaryRequest {
    private company;
    private username;
    private token;
    private hourlyWage;
    private contractedHoursPerWeek;
    getCompany(): string;
    getUsername(): string;
    getToken(): string;
    getHourlyWage(): number;
    getContractedHoursPerWeek(): number;
}
