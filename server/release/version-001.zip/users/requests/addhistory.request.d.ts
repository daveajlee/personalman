export declare class AddHistoryRequest {
    private company;
    private username;
    private token;
    private date;
    private reason;
    private comment;
    getCompany(): string;
    getUsername(): string;
    getDate(): string;
    getReason(): string;
    getComment(): string;
    getToken(): string;
}
