"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const user_model_1 = require("./models/user.model");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const userhistory_entry_1 = require("./models/userhistory.entry");
let UsersService = class UsersService {
    configService;
    userModel;
    tokenLength;
    timeoutInMinutes;
    constructor(configService, userModel) {
        this.configService = configService;
        this.userModel = userModel;
        this.tokenLength = this.configService.get('TOKEN_LENGTH');
        this.timeoutInMinutes = this.configService.get('LOGOUT_MINUTES');
    }
    loggedInTokens = new Map();
    save(user) {
        const createdUser = new this.userModel(user);
        return createdUser.save() != null;
    }
    async findByCompanyAndUserName(company, userName) {
        return await this.userModel.findOne({ company, userName });
    }
    async findUserByDateOfBirthAndNameAndCompany(dateOfBirth, firstName, lastName, company) {
        return await this.userModel.findOne({ dateOfBirth, firstName, lastName, company });
    }
    async findByCompany(company) {
        return await this.userModel.find({ company });
    }
    async delete(user) {
        if (user != null) {
            var result = await this.userModel.deleteOne({ username: user["username"] });
            return result.deletedCount != 0;
        }
        return false;
    }
    async deleteAllUsers(company) {
        var usersToDelete = await this.userModel.find({ company }).exec();
        if (usersToDelete != null) {
            usersToDelete.forEach(user => this.userModel.deleteOne(user));
        }
    }
    async deactivate(user, leavingDate, resigned, reason) {
        user["endDate"] = leavingDate;
        user["accountStatus"] = "DEACTIVATED";
        if (resigned) {
            this.addUserHistoryEntry(user, leavingDate, "Resigned", reason);
        }
        else {
            this.addUserHistoryEntry(user, leavingDate, "Sacked", reason);
        }
        var remainingAnnualLeave = 0;
        var numWorkingDays = (leavingDate.getTime() - (new Date(leavingDate.getFullYear(), 0, 1)).getTime()) / 86400000;
        remainingAnnualLeave = Math.ceil((user["leaveEntitlementPerYear"] / 365) * numWorkingDays);
        return remainingAnnualLeave;
    }
    updateSalaryInformation(user, hourlyWage, contractedHoursPerWeek) {
        user["hourlyWage"] = hourlyWage;
        user["contractedHoursPerWeek"] = contractedHoursPerWeek;
        const createdUser = new this.userModel(user);
        return createdUser.save() != null;
    }
    async addTrainingCourse(user, trainingCourse) {
        var trainingsList = user["trainingsList"];
        trainingsList.push(trainingCourse);
        const createdUser = new this.userModel(user);
        return await createdUser.save() != null;
    }
    addHoursForDate(user, hours, date) {
        if (user["timesheet"] == null) {
            user["timesheet"] = new Map();
        }
        if (user["timesheet"].get(date) != null) {
            user["timesheet"].set(date, user["timesheet"].get(date) + hours);
        }
        else {
            user["timesheet"].set(date, hours);
        }
        const createdUser = new this.userModel(user);
        return createdUser.save() != null;
    }
    addUserHistoryEntry(user, date, userHistoryReason, comment) {
        var historyEntryList = user["userHistoryEntryList"];
        if (historyEntryList == null) {
            historyEntryList = [];
        }
        historyEntryList.push(new userhistory_entry_1.UserHistoryEntry(date, userHistoryReason, comment));
        user["userHistoryEntryList"] = historyEntryList;
        const createdUser = new this.userModel(user);
        return createdUser.save() != null;
    }
    getHoursForDate(user, date) {
        let hours = 0;
        if (user != null) {
            if (user["timesheet"].get(date) !== undefined) {
                hours = user["timesheet"].get(date);
            }
        }
        return hours;
    }
    getHoursForDateRange(user, startDate, endDate) {
        var hours = 0;
        var date = this.convertToDate(startDate);
        var endDateObj = this.convertToDate(endDate);
        while (date.getTime() <= endDateObj.getTime()) {
            hours += this.getHoursForDate(user, this.addZeroPrefix(date.getDate()) + "-" + this.addZeroPrefix((date.getMonth() + 1)) + "-" + date.getFullYear());
            date = new Date(date.getTime() + 86400000);
        }
        return hours;
    }
    convertToDate(date) {
        let dateSplit = date.split("-");
        return new Date(parseInt(dateSplit[2]), parseInt(dateSplit[1]) - 1, parseInt(dateSplit[0]));
    }
    addZeroPrefix(checkNumber) {
        if (checkNumber < 10) {
            return "0" + checkNumber;
        }
        return "" + checkNumber;
    }
    generateAuthToken(userName) {
        var token = userName + "-" + this.createRandomString(this.tokenLength);
        this.loggedInTokens.set(token, new Date(Date.now() + this.timeoutInMinutes * 60000));
        return token;
    }
    createRandomString(length) {
        const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        let result = "";
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }
    checkAuthToken(token) {
        return this.loggedInTokens.has(token) && this.loggedInTokens.get(token).getTime() >= new Date().getTime();
    }
    removeAuthToken(token) {
        this.loggedInTokens.delete(token);
    }
    async resetUserPassword(company, username, newPassword) {
        var user = await this.findByCompanyAndUserName(company, username);
        if (user != null) {
            user["password"] = newPassword;
            const createdUser = new this.userModel(user);
            return createdUser.save() != null;
        }
        return false;
    }
    async changePassword(company, username, oldPassword, newPassword) {
        var user = await this.findByCompanyAndUserName(company, username);
        if (user != null) {
            if (user["password"] === oldPassword) {
                user["password"] = newPassword;
                const createdUser = new this.userModel(user);
                return createdUser.save() != null;
            }
        }
        return false;
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = __decorate([
    (0, common_1.Injectable)(),
    __param(1, (0, mongoose_1.InjectModel)(user_model_1.User.name)),
    __metadata("design:paramtypes", [config_1.ConfigService, mongoose_2.Model])
], UsersService);
//# sourceMappingURL=users.service.js.map