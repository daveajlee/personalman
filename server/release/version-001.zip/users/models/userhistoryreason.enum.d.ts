export declare enum UserHistoryReason {
    JOINED = "Joined",
    PAID = "Paid",
    EVALUATED = "Evaluated",
    WARNED = "Warned",
    RESIGNED = "Resigned",
    SACKED = "Sacked"
}
