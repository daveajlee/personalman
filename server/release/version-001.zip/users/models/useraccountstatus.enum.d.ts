export declare enum UserAccountStatus {
    ACTIVE = "Active",
    DEACTIVATED = "Deactivated"
}
