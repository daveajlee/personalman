"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserHistoryReason = void 0;
var UserHistoryReason;
(function (UserHistoryReason) {
    UserHistoryReason["JOINED"] = "Joined";
    UserHistoryReason["PAID"] = "Paid";
    UserHistoryReason["EVALUATED"] = "Evaluated";
    UserHistoryReason["WARNED"] = "Warned";
    UserHistoryReason["RESIGNED"] = "Resigned";
    UserHistoryReason["SACKED"] = "Sacked";
})(UserHistoryReason || (exports.UserHistoryReason = UserHistoryReason = {}));
;
//# sourceMappingURL=userhistoryreason.enum.js.map