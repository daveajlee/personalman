"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.User = void 0;
const userhistory_entry_1 = require("./userhistory.entry");
class User {
    firstName;
    lastName;
    userName;
    password;
    company;
    leaveEntitlementPerYear;
    workingDays;
    position;
    startDate;
    endDate;
    accountStatus;
    dateOfBirth;
    role;
    hourlyWage;
    contractedHoursPerWeek;
    trainingsList;
    timesheet;
    userHistoryEntryList;
    constructor(firstName, surname, leaveEntitlementPerYear, position, startDate, username, password, company, workingDays, role, dateOfBirth, accountStatus) {
        this.firstName = firstName;
        this.lastName = surname;
        this.leaveEntitlementPerYear = leaveEntitlementPerYear;
        this.position = position;
        this.startDate = startDate;
        this.userName = username;
        this.password = password;
        this.company = company;
        if (workingDays) {
            this.workingDays = workingDays.split(",");
        }
        else {
            this.workingDays = [];
        }
        this.role = role;
        this.dateOfBirth = dateOfBirth;
        this.accountStatus = accountStatus;
    }
    addTrainingCourse(trainingCourse) {
        this.trainingsList.push(trainingCourse);
    }
    addHoursForDate(hours, date) {
        if (this.timesheet.get(date) != null) {
            this.timesheet.set(date, this.timesheet.get(date) + hours);
        }
        else {
            this.timesheet.set(date, hours);
        }
    }
    getHoursForDate(date) {
        if (this.timesheet.get(date) !== undefined) {
            return this.timesheet.get(date);
        }
        else {
            return 0;
        }
    }
    addUserHistoryEntry(date, userHistoryReason, comment) {
        if (this.userHistoryEntryList == null) {
            this.userHistoryEntryList = [];
        }
        if (userHistoryReason != null) {
            this.userHistoryEntryList.push(new userhistory_entry_1.UserHistoryEntry(date, userHistoryReason, comment));
        }
    }
    getPassword() {
        return this.password;
    }
    setPassword(password) {
        this.password = password;
    }
    getUserHistoryEntryList() {
        return this.userHistoryEntryList;
    }
    setUserHistoryEntryList(userHistoryEntryList) {
        this.userHistoryEntryList = userHistoryEntryList;
    }
    getTimesheet() {
        return this.timesheet;
    }
    setTimesheet(timesheet) {
        this.timesheet = timesheet;
    }
    getTrainingsList() {
        return this.trainingsList;
    }
    setTrainingsList(trainingsList) {
        this.trainingsList = trainingsList;
    }
    setHourlyWage(hourlyWage) {
        this.hourlyWage = hourlyWage;
    }
    setContractedHoursPerWeek(contractedHoursPerWeek) {
        this.contractedHoursPerWeek = contractedHoursPerWeek;
    }
    getLeaveEntitlementPerYear() {
        return this.leaveEntitlementPerYear;
    }
    setAccountStatus(accountStatus) {
        this.accountStatus = accountStatus;
    }
    setEndDate(endDate) {
        this.endDate = endDate;
    }
    getAccountStatus() {
        return this.accountStatus;
    }
    getEndDate() {
        return this.endDate;
    }
    getContractedHoursPerWeek() {
        return this.contractedHoursPerWeek;
    }
    getHourlyWage() {
        return this.hourlyWage;
    }
    getDateOfBirth() {
        return this.dateOfBirth;
    }
    getRole() {
        return this.role;
    }
    getStartDate() {
        return this.startDate;
    }
    getPosition() {
        return this.position;
    }
    getFirstName() {
        return this.firstName;
    }
    getLastName() {
        return this.lastName;
    }
    getUsername() {
        return this.userName;
    }
    getCompany() {
        return this.company;
    }
    getWorkingDays() {
        return this.workingDays;
    }
}
exports.User = User;
//# sourceMappingURL=user.model.js.map