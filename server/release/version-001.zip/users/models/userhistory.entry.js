"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserHistoryEntry = void 0;
class UserHistoryEntry {
    date;
    reason;
    comment;
    constructor(date, reason, comment) {
        this.date = date;
        this.reason = reason;
        this.comment = comment;
    }
    getUserHistoryReason() {
        return this.reason;
    }
    getComment() {
        return this.comment;
    }
    getDate() {
        return this.date;
    }
}
exports.UserHistoryEntry = UserHistoryEntry;
//# sourceMappingURL=userhistory.entry.js.map