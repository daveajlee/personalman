export declare class UserHistoryEntry {
    date: Date;
    reason: string;
    comment: string;
    constructor(date: Date, reason: string, comment: string);
    getUserHistoryReason(): string;
    getComment(): string;
    getDate(): Date;
}
