"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserAccountStatus = void 0;
var UserAccountStatus;
(function (UserAccountStatus) {
    UserAccountStatus["ACTIVE"] = "Active";
    UserAccountStatus["DEACTIVATED"] = "Deactivated";
})(UserAccountStatus || (exports.UserAccountStatus = UserAccountStatus = {}));
//# sourceMappingURL=useraccountstatus.enum.js.map