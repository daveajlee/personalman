"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserSchema = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
exports.UserSchema = new mongoose_1.default.Schema({
    firstName: String,
    lastName: String,
    userName: String,
    password: String,
    company: String,
    leaveEntitlementPerYear: Number,
    workingDays: [String],
    position: String,
    startDate: Date,
    endDate: Date,
    accountStatus: String,
    dateOfBirth: Date,
    role: String,
    hourlyWage: Number,
    contractedHoursPerWeek: Number,
    trainingsList: [String],
    timesheet: (Map),
    userHistoryEntryList: [{
            date: Date,
            reason: String,
            comment: String
        }]
});
//# sourceMappingURL=user.schema.js.map