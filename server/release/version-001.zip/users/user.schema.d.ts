import mongoose from "mongoose";
export declare const UserSchema: mongoose.Schema<any, mongoose.Model<any, any, any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    workingDays: string[];
    trainingsList: string[];
    userHistoryEntryList: mongoose.Types.DocumentArray<{
        date?: NativeDate | null | undefined;
        comment?: string | null | undefined;
        reason?: string | null | undefined;
    }, mongoose.Types.Subdocument<mongoose.mongo.ObjectId, unknown, {
        date?: NativeDate | null | undefined;
        comment?: string | null | undefined;
        reason?: string | null | undefined;
    }, {}, {}> & {
        date?: NativeDate | null | undefined;
        comment?: string | null | undefined;
        reason?: string | null | undefined;
    }>;
    firstName?: string | null | undefined;
    lastName?: string | null | undefined;
    userName?: string | null | undefined;
    password?: string | null | undefined;
    company?: string | null | undefined;
    leaveEntitlementPerYear?: number | null | undefined;
    position?: string | null | undefined;
    startDate?: NativeDate | null | undefined;
    endDate?: NativeDate | null | undefined;
    accountStatus?: string | null | undefined;
    dateOfBirth?: NativeDate | null | undefined;
    role?: string | null | undefined;
    hourlyWage?: number | null | undefined;
    contractedHoursPerWeek?: number | null | undefined;
    timesheet?: Map<string, unknown> | null | undefined;
}, mongoose.Document<unknown, {}, {
    workingDays: string[];
    trainingsList: string[];
    userHistoryEntryList: mongoose.Types.DocumentArray<{
        date?: NativeDate | null | undefined;
        comment?: string | null | undefined;
        reason?: string | null | undefined;
    }, mongoose.Types.Subdocument<mongoose.mongo.ObjectId, unknown, {
        date?: NativeDate | null | undefined;
        comment?: string | null | undefined;
        reason?: string | null | undefined;
    }, {}, {}> & {
        date?: NativeDate | null | undefined;
        comment?: string | null | undefined;
        reason?: string | null | undefined;
    }>;
    firstName?: string | null | undefined;
    lastName?: string | null | undefined;
    userName?: string | null | undefined;
    password?: string | null | undefined;
    company?: string | null | undefined;
    leaveEntitlementPerYear?: number | null | undefined;
    position?: string | null | undefined;
    startDate?: NativeDate | null | undefined;
    endDate?: NativeDate | null | undefined;
    accountStatus?: string | null | undefined;
    dateOfBirth?: NativeDate | null | undefined;
    role?: string | null | undefined;
    hourlyWage?: number | null | undefined;
    contractedHoursPerWeek?: number | null | undefined;
    timesheet?: Map<string, unknown> | null | undefined;
}, {
    id: string;
}, mongoose.DefaultSchemaOptions> & Omit<{
    workingDays: string[];
    trainingsList: string[];
    userHistoryEntryList: mongoose.Types.DocumentArray<{
        date?: NativeDate | null | undefined;
        comment?: string | null | undefined;
        reason?: string | null | undefined;
    }, mongoose.Types.Subdocument<mongoose.mongo.ObjectId, unknown, {
        date?: NativeDate | null | undefined;
        comment?: string | null | undefined;
        reason?: string | null | undefined;
    }, {}, {}> & {
        date?: NativeDate | null | undefined;
        comment?: string | null | undefined;
        reason?: string | null | undefined;
    }>;
    firstName?: string | null | undefined;
    lastName?: string | null | undefined;
    userName?: string | null | undefined;
    password?: string | null | undefined;
    company?: string | null | undefined;
    leaveEntitlementPerYear?: number | null | undefined;
    position?: string | null | undefined;
    startDate?: NativeDate | null | undefined;
    endDate?: NativeDate | null | undefined;
    accountStatus?: string | null | undefined;
    dateOfBirth?: NativeDate | null | undefined;
    role?: string | null | undefined;
    hourlyWage?: number | null | undefined;
    contractedHoursPerWeek?: number | null | undefined;
    timesheet?: Map<string, unknown> | null | undefined;
} & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}, "id"> & {
    id: string;
}, unknown, {
    workingDays: string[];
    trainingsList: string[];
    userHistoryEntryList: mongoose.Types.DocumentArray<{
        date?: NativeDate | null | undefined;
        comment?: string | null | undefined;
        reason?: string | null | undefined;
    }, mongoose.Types.Subdocument<mongoose.mongo.ObjectId, unknown, {
        date?: NativeDate | null | undefined;
        comment?: string | null | undefined;
        reason?: string | null | undefined;
    }, {}, {}> & {
        date?: NativeDate | null | undefined;
        comment?: string | null | undefined;
        reason?: string | null | undefined;
    }>;
    firstName?: string | null | undefined;
    lastName?: string | null | undefined;
    userName?: string | null | undefined;
    password?: string | null | undefined;
    company?: string | null | undefined;
    leaveEntitlementPerYear?: number | null | undefined;
    position?: string | null | undefined;
    startDate?: NativeDate | null | undefined;
    endDate?: NativeDate | null | undefined;
    accountStatus?: string | null | undefined;
    dateOfBirth?: NativeDate | null | undefined;
    role?: string | null | undefined;
    hourlyWage?: number | null | undefined;
    contractedHoursPerWeek?: number | null | undefined;
    timesheet?: {
        [x: string]: unknown;
    } | null | undefined;
} & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}>;
