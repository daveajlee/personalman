"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const addhistory_request_1 = require("./requests/addhistory.request");
const addtimesheethours_request_1 = require("./requests/addtimesheethours.request");
const addtraining_request_1 = require("./requests/addtraining.request");
const changepassword_request_1 = require("./requests/changepassword.request");
const deactivateuser_request_1 = require("./requests/deactivateuser.request");
const logout_request_1 = require("./requests/logout.request");
const login_response_1 = require("./responses/login.response");
const login_request_1 = require("./requests/login.request");
const resetuser_request_1 = require("./requests/resetuser.request");
const updatesalary_request_1 = require("./requests/updatesalary.request");
const user_response_1 = require("./responses/user.response");
const user_request_1 = require("./requests/user.request");
const users_service_1 = require("./users.service");
const user_utils_1 = require("./utils/user.utils");
const company_service_1 = require("../company/company.service");
const deactivateuser_response_1 = require("./responses/deactivateuser.response");
let UserController = class UserController {
    userService;
    companyService;
    constructor(userService, companyService) {
        this.userService = userService;
        this.companyService = companyService;
    }
    logout(logoutRequest, res) {
        this.userService.removeAuthToken(logoutRequest.getToken());
        res.status(common_1.HttpStatus.OK).send();
    }
    async login(loginRequest, res) {
        var user = await this.userService.findByCompanyAndUserName(loginRequest.getCompany(), loginRequest.getUsername());
        if (user != null && user["accountStatus"] === 'ACTIVE' && user["password"] == loginRequest.getPassword()) {
            res.status(common_1.HttpStatus.OK).json(new login_response_1.LoginResponse("", this.userService.generateAuthToken(loginRequest.getUsername())));
        }
        else if (user != null) {
            res.status(common_1.HttpStatus.FORBIDDEN).json(new login_response_1.LoginResponse("Password was incorrect!", ""));
        }
        else {
            res.status(common_1.HttpStatus.FORBIDDEN).json(new login_response_1.LoginResponse("User was not found", ""));
        }
    }
    async findUser(company, username, token, res) {
        if (token == null || !this.userService.checkAuthToken(token)) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        else {
            var user = await this.userService.findByCompanyAndUserName(company, username);
            if (user == null) {
                res.status(common_1.HttpStatus.NO_CONTENT).send();
            }
            else {
                res.status(common_1.HttpStatus.OK).json(user_utils_1.UserUtils.convertUserToUserResponse(user));
            }
        }
    }
    async addUser(userRequest, res) {
        if (userRequest.getFirstName() === "" || userRequest.getSurname() === ""
            || userRequest.getPosition() === "" || userRequest.getStartDate() === ""
            || userRequest.getUsername() === "" || userRequest.getWorkingDays() === ""
            || userRequest.getCompany() === "") {
            res.status(common_1.HttpStatus.BAD_REQUEST).send();
        }
        if (userRequest.getLeaveEntitlementPerYear() <= 0) {
            let company = await this.companyService.getCompany(userRequest.getCompany());
            userRequest.setLeaveEntitlementPerYear(company.getDefaultAnnualLeaveInDays());
        }
        var startDate = this.convertToDate(userRequest.getStartDate());
        var dateOfBirth = this.convertToDate(userRequest.getDateOfBirth());
        if (startDate == null || dateOfBirth == null) {
            res.status(common_1.HttpStatus.BAD_REQUEST).send();
        }
        var user = user_utils_1.UserUtils.convertUserRequestToUser(userRequest, startDate, dateOfBirth);
        this.userService.save(user) ? res.status(common_1.HttpStatus.CREATED).send() : res.status(common_1.HttpStatus.INTERNAL_SERVER_ERROR).send();
    }
    convertToDate(date) {
        let dateSplit = date.split("-");
        return new Date(parseInt(dateSplit[2]), parseInt(dateSplit[1]) - 1, parseInt(dateSplit[0]));
    }
    async deleteUser(company, username, token, res) {
        if (token == null || !this.userService.checkAuthToken(token)) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        else {
            var user = await this.userService.findByCompanyAndUserName(company, username);
            if (user == null) {
                res.status(common_1.HttpStatus.NO_CONTENT).send();
            }
            else {
                await this.userService.delete(user);
                res.status(common_1.HttpStatus.OK).send();
            }
        }
    }
    async addTraining(addTrainingRequest, res) {
        var status = this.validateAndAuthenticateRequest(addTrainingRequest.getCompany(), addTrainingRequest.getUsername(), addTrainingRequest.getToken(), res);
        if (status != null) {
            res.status(status.statusCode).send();
        }
        var user = await this.userService.findByCompanyAndUserName(addTrainingRequest.getCompany(), addTrainingRequest.getUsername());
        if (user == null) {
            res.status(common_1.HttpStatus.NO_CONTENT).send();
        }
        else {
            await this.userService.addTrainingCourse(user, addTrainingRequest.getTrainingCourse()) ?
                res.status(common_1.HttpStatus.OK).send() : res.status(common_1.HttpStatus.INTERNAL_SERVER_ERROR).send();
        }
    }
    async retrieveTimesheet(company, username, token, startDate, endDate, res) {
        if (token == null || !this.userService.checkAuthToken(token)) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        else {
            var user = await this.userService.findByCompanyAndUserName(company, username);
            if (user == null) {
                res.status(common_1.HttpStatus.NO_CONTENT).send();
            }
            else {
                if (startDate != null && endDate != null && startDate == endDate) {
                    res.status(common_1.HttpStatus.OK).json(this.userService.getHoursForDate(user, startDate));
                }
                else {
                    res.status(common_1.HttpStatus.OK).json(this.userService.getHoursForDateRange(user, startDate, endDate));
                }
            }
        }
    }
    async addHours(addHoursRequest, res) {
        if (addHoursRequest.getToken() == null || !this.userService.checkAuthToken(addHoursRequest.getToken())) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        else {
            var user = await this.userService.findByCompanyAndUserName(addHoursRequest.getCompany(), addHoursRequest.getUsername());
            if (user == null) {
                res.status(common_1.HttpStatus.NO_CONTENT).send();
            }
            else {
                this.userService.addHoursForDate(user, addHoursRequest.getHours(), addHoursRequest.getDate()) ?
                    res.status(common_1.HttpStatus.OK).send() : res.status(common_1.HttpStatus.INTERNAL_SERVER_ERROR).send();
            }
        }
    }
    async updateSalary(updateSalaryRequest, res) {
        if (updateSalaryRequest.getToken() == null || !this.userService.checkAuthToken(updateSalaryRequest.getToken())) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        else {
            var user = await this.userService.findByCompanyAndUserName(updateSalaryRequest.getCompany(), updateSalaryRequest.getUsername());
            if (user == null) {
                res.status(common_1.HttpStatus.NO_CONTENT).send();
            }
            else {
                this.userService.updateSalaryInformation(user, updateSalaryRequest.getHourlyWage(), updateSalaryRequest.getContractedHoursPerWeek()) ?
                    res.status(common_1.HttpStatus.OK).send() : res.status(common_1.HttpStatus.INTERNAL_SERVER_ERROR).send();
            }
        }
    }
    async resetUser(resetUserRequest, res) {
        if (resetUserRequest.getToken() == null || !this.userService.checkAuthToken(resetUserRequest.getToken())) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        var result = await this.userService.resetUserPassword(resetUserRequest.getCompany(), resetUserRequest.getUsername(), resetUserRequest.getPassword());
        result ? res.status(common_1.HttpStatus.OK).send() : res.status(common_1.HttpStatus.NOT_FOUND).send();
    }
    async changePassword(changePasswordRequest, res) {
        if (changePasswordRequest.getToken() == null || !this.userService.checkAuthToken(changePasswordRequest.getToken())) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        else {
            var result = await this.userService.changePassword(changePasswordRequest.getCompany(), changePasswordRequest.getUsername(), changePasswordRequest.getCurrentPassword(), changePasswordRequest.getNewPassword());
            result ? res.status(common_1.HttpStatus.OK).send() : res.status(common_1.HttpStatus.NOT_FOUND).send();
        }
    }
    async addHistoryEntry(addHistoryRequest, res) {
        if (addHistoryRequest.getToken() == null || !this.userService.checkAuthToken(addHistoryRequest.getToken())) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        else {
            var user = await this.userService.findByCompanyAndUserName(addHistoryRequest.getCompany(), addHistoryRequest.getUsername());
            if (user == null) {
                res.status(common_1.HttpStatus.NO_CONTENT).send();
            }
            else {
                this.userService.addUserHistoryEntry(user, this.convertToDate(addHistoryRequest.getDate()), addHistoryRequest.getReason(), addHistoryRequest.getComment()) ?
                    res.status(common_1.HttpStatus.OK).send() : res.status(common_1.HttpStatus.INTERNAL_SERVER_ERROR).send();
            }
        }
    }
    async deactivate(deactivateUserRequest, res) {
        if (deactivateUserRequest.getToken() == null || !this.userService.checkAuthToken(deactivateUserRequest.getToken())) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        else {
            var user = await this.userService.findByCompanyAndUserName(deactivateUserRequest.getCompany(), deactivateUserRequest.getUsername());
            if (user == null) {
                res.status(common_1.HttpStatus.NO_CONTENT).send();
            }
            else {
                res.status(common_1.HttpStatus.OK).json(new deactivateuser_response_1.DeactivateUserResponse(await this.userService.deactivate(user, this.convertToDate(deactivateUserRequest.getLeavingDate()), deactivateUserRequest.isResigned(), deactivateUserRequest.getReason())));
            }
        }
    }
    async getUser(name, dateOfBirth, company, token, res) {
        if (token == null || !this.userService.checkAuthToken(token)) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        else if (name == null || dateOfBirth == null || company === '') {
            res.status(common_1.HttpStatus.BAD_REQUEST).send();
        }
        else {
            var user = await this.userService.findUserByDateOfBirthAndNameAndCompany(this.convertToDate(dateOfBirth), name.split(" ")[0], name.split(" ")[1], company);
            if (user == null) {
                res.status(common_1.HttpStatus.NO_CONTENT).send();
            }
            else {
                res.status(common_1.HttpStatus.OK).json(user_utils_1.UserUtils.convertUserToUserResponse(user));
            }
        }
    }
    validateAndAuthenticateRequest(company, username, token, res) {
        if (username === '' || company === '') {
            return res.status(common_1.HttpStatus.BAD_REQUEST).send();
        }
        if (token == null || !this.userService.checkAuthToken(token)) {
            return res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        return res.status(common_1.HttpStatus.OK).send();
    }
};
exports.UserController = UserController;
__decorate([
    (0, common_1.Post)('logout'),
    (0, swagger_1.ApiOperation)({ summary: 'Logout', description: 'Logout from the system' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully processed logout request' }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [logout_request_1.LogoutRequest, Object]),
    __metadata("design:returntype", void 0)
], UserController.prototype, "logout", null);
__decorate([
    (0, common_1.Post)('login'),
    (0, swagger_1.ApiOperation)({ summary: 'Login', description: 'Login to the system' }),
    (0, swagger_1.ApiOkResponse)({
        description: 'Successfully processed login request',
        type: login_response_1.LoginResponse,
    }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [login_request_1.LoginRequest, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "login", null);
__decorate([
    (0, common_1.Get)('/'),
    (0, swagger_1.ApiOperation)({ summary: 'Find a user', description: 'Find a user in the system.' }),
    (0, swagger_1.ApiOkResponse)({
        description: 'Successfully found user',
        type: user_response_1.UserResponse,
    }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Successful but no user found' }),
    __param(0, (0, common_1.Query)('company')),
    __param(1, (0, common_1.Query)('username')),
    __param(2, (0, common_1.Query)('token')),
    __param(3, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "findUser", null);
__decorate([
    (0, common_1.Post)('/'),
    (0, swagger_1.ApiOperation)({ summary: 'Add a user', description: 'Add a user to the system.' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'Successfully created user' }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [user_request_1.UserRequest, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "addUser", null);
__decorate([
    (0, common_1.Delete)('/'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete a user', description: 'Delete a user from the system.' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully delete user' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Successful but no user found' }),
    __param(0, (0, common_1.Query)('company')),
    __param(1, (0, common_1.Query)('username')),
    __param(2, (0, common_1.Query)('token')),
    __param(3, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "deleteUser", null);
__decorate([
    (0, common_1.Patch)('/training'),
    (0, swagger_1.ApiOperation)({ summary: 'Add a training course', description: 'Add a training course for a particular user.' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully added training course' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'No user found' }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [addtraining_request_1.AddTrainingRequest, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "addTraining", null);
__decorate([
    (0, common_1.Get)('/timesheet'),
    (0, swagger_1.ApiOperation)({ summary: "Retrieve the user's timesheet", description: "Retrieve number of hours for a specified date (range) for a specified user." }),
    (0, swagger_1.ApiOkResponse)({
        description: 'Successfully retrieved hours',
        type: Number,
    }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'No user found' }),
    __param(0, (0, common_1.Query)('company')),
    __param(1, (0, common_1.Query)('username')),
    __param(2, (0, common_1.Query)('token')),
    __param(3, (0, common_1.Query)('startDate')),
    __param(4, (0, common_1.Query)('endDate')),
    __param(5, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "retrieveTimesheet", null);
__decorate([
    (0, common_1.Patch)('/timesheet'),
    (0, swagger_1.ApiOperation)({ summary: "Add a number of hours to the user's timesheet", description: "Add a number of hours to a specified date for a specified user." }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully added hours' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'No user found' }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [addtimesheethours_request_1.AddTimesheetHoursRequest, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "addHours", null);
__decorate([
    (0, common_1.Patch)('/salary'),
    (0, swagger_1.ApiOperation)({ summary: 'Update salary information', description: "Update salary information for a particular user." }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully updated salary information' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'No user found' }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [updatesalary_request_1.UpdateSalaryRequest, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "updateSalary", null);
__decorate([
    (0, common_1.Patch)('/reset'),
    (0, swagger_1.ApiOperation)({ summary: 'Reset user', description: 'Reset password for a user' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully processed reset user request' }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [resetuser_request_1.ResetUserRequest, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "resetUser", null);
__decorate([
    (0, common_1.Patch)('/password'),
    (0, swagger_1.ApiOperation)({ summary: 'Change Password', description: 'Change password for a user' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully processed change password request' }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [changepassword_request_1.ChangePasswordRequest, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "changePassword", null);
__decorate([
    (0, common_1.Patch)('/history'),
    (0, swagger_1.ApiOperation)({ summary: 'Add a new history entry', description: 'Add a new history entry for a particular user.' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully added history entry' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'No user found' }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [addhistory_request_1.AddHistoryRequest, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "addHistoryEntry", null);
__decorate([
    (0, common_1.Patch)('/deactivate'),
    (0, swagger_1.ApiOperation)({ summary: 'Deactivate user', description: 'Deactivate a user from the system' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully deactivated user' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Successful but no user found' }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [deactivateuser_request_1.DeactivateUserRequest, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "deactivate", null);
__decorate([
    (0, common_1.Get)('/getUser'),
    (0, swagger_1.ApiOperation)({ summary: 'Get user', description: 'Method to get a users details by name and date of birth.' }),
    (0, swagger_1.ApiOkResponse)({
        description: 'Successfully retrieved user details',
        type: user_response_1.UserResponse
    }),
    (0, swagger_1.ApiResponse)({ status: 500, description: 'Database not available' }),
    __param(0, (0, common_1.Query)('name')),
    __param(1, (0, common_1.Query)('dateOfBirth')),
    __param(2, (0, common_1.Query)('company')),
    __param(3, (0, common_1.Query)('token')),
    __param(4, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "getUser", null);
__decorate([
    __param(3, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, Object]),
    __metadata("design:returntype", Object)
], UserController.prototype, "validateAndAuthenticateRequest", null);
exports.UserController = UserController = __decorate([
    (0, common_1.Controller)('user'),
    __metadata("design:paramtypes", [users_service_1.UsersService, company_service_1.CompanyService])
], UserController);
//# sourceMappingURL=user.controller.js.map