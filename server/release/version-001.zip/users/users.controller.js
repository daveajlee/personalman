"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const paiduser_request_1 = require("./requests/paiduser.request");
const payuser_response_1 = require("./responses/payuser.response");
const payusers_response_1 = require("./responses/payusers.response");
const users_response_1 = require("./responses/users.response");
const users_service_1 = require("./users.service");
const userhistoryreason_enum_1 = require("./models/userhistoryreason.enum");
const user_utils_1 = require("./utils/user.utils");
let UsersController = class UsersController {
    userService;
    constructor(userService) {
        this.userService = userService;
    }
    async markUsersPaid(paidUserRequest, res) {
        if (paidUserRequest.token == null || !this.userService.checkAuthToken(paidUserRequest.token)) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        if (paidUserRequest.company === '') {
            res.status(common_1.HttpStatus.BAD_REQUEST).send();
        }
        for (var i = 0; i < paidUserRequest.employeePayTable.length; i++) {
            if (await this.processPaidUser(paidUserRequest.employeePayTable[i], paidUserRequest) === false) {
                res.status(common_1.HttpStatus.INTERNAL_SERVER_ERROR).send();
            }
        }
        res.status(common_1.HttpStatus.OK).send();
    }
    async processPaidUser(username, paidUserRequest) {
        var user = await this.userService.findByCompanyAndUserName(paidUserRequest.company, username["username"]);
        if (user != null) {
            var result = await this.userService.addUserHistoryEntry(user, new Date(), userhistoryreason_enum_1.UserHistoryReason.PAID, "Paid " + username["amount"] + " for date range " +
                paidUserRequest.startDate + " - " + paidUserRequest.endDate);
            if (result != false) {
                return true;
            }
        }
        return false;
    }
    async payUsers(company, token, startDate, endDate, res) {
        if (token == null || !this.userService.checkAuthToken(token)) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        if (company === '') {
            res.sendStatus(common_1.HttpStatus.BAD_REQUEST).send();
        }
        var users = await this.userService.findByCompany(company);
        if (users.length === 0) {
            res.status(common_1.HttpStatus.NO_CONTENT).send();
        }
        var totalSum = 0;
        var employeePayTable = new Array();
        users.forEach((user) => {
            if (user != null) {
                var sumToBePaid = 0;
                while (startDate != null && endDate != null && (startDate <= endDate)) {
                    if ((this.userService.getHoursForDate(user, startDate) != null)) {
                        sumToBePaid += (this.userService.getHoursForDate(user, startDate) * user["hourlyWage"]);
                    }
                    var startDateObj = this.convertToDate(startDate);
                    startDateObj.setDate(startDateObj.getDate() + 1);
                    startDate = this.addZeroPrefix(startDateObj.getDate()) + "-" + this.addZeroPrefix((startDateObj.getMonth() + 1)) + "-" + startDateObj.getFullYear();
                }
                employeePayTable.push(new payuser_response_1.PayUserResponse(user["userName"], sumToBePaid));
                totalSum += sumToBePaid;
            }
        });
        let payUsersResponse = new payusers_response_1.PayUsersResponse(employeePayTable, totalSum);
        res.status(common_1.HttpStatus.OK).json(payUsersResponse);
    }
    convertToDate(date) {
        let dateSplit = date.split("-");
        return new Date(parseInt(dateSplit[2]), parseInt(dateSplit[1]) - 1, parseInt(dateSplit[0]));
    }
    addZeroPrefix(checkNumber) {
        if (checkNumber < 10) {
            return "0" + checkNumber;
        }
        return "" + checkNumber;
    }
    async findAllUsers(company, token, res) {
        if (token == null || !this.userService.checkAuthToken(token)) {
            res.status(common_1.HttpStatus.FORBIDDEN).send();
        }
        if (company === '') {
            res.status(common_1.HttpStatus.BAD_REQUEST).send();
        }
        var users = await this.userService.findByCompany(company);
        if (users.length === 0) {
            res.status(common_1.HttpStatus.NO_CONTENT).send();
        }
        var userResponses = new Array();
        for (var i = 0; i < users.length; i++) {
            userResponses[i] = user_utils_1.UserUtils.convertUserToUserResponse(users[i]);
        }
        res.status(common_1.HttpStatus.OK).json(new users_response_1.UsersResponse(userResponses.length, userResponses));
    }
};
exports.UsersController = UsersController;
__decorate([
    (0, common_1.Post)('paid'),
    (0, swagger_1.ApiOperation)({ summary: 'Mark users as paid for a company', description: 'Mark users as paid for a company within a specific date range.' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully found user(s) and their pay' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Successful but no users found' }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [paiduser_request_1.PaidUserRequest, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "markUsersPaid", null);
__decorate([
    (0, common_1.Get)('pay'),
    (0, swagger_1.ApiOperation)({ summary: 'Pay all users for a company', description: 'Pay all users for a company within a specific date range.' }),
    (0, swagger_1.ApiOkResponse)({
        description: 'Successfully found user(s) and their pay',
        type: payusers_response_1.PayUsersResponse,
    }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Successful but no users found' }),
    __param(0, (0, common_1.Query)('company')),
    __param(1, (0, common_1.Query)('token')),
    __param(2, (0, common_1.Query)('startDate')),
    __param(3, (0, common_1.Query)('endDate')),
    __param(4, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "payUsers", null);
__decorate([
    (0, common_1.Get)('/'),
    (0, swagger_1.ApiOperation)({ summary: 'Find all users for a company', description: 'Find all users for a company to the system.' }),
    (0, swagger_1.ApiOkResponse)({
        description: 'Successfully found user(s)',
        type: users_response_1.UsersResponse,
    }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Successful but no users found' }),
    __param(0, (0, common_1.Query)('company')),
    __param(1, (0, common_1.Query)('token')),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], UsersController.prototype, "findAllUsers", null);
exports.UsersController = UsersController = __decorate([
    (0, common_1.Controller)('users'),
    __metadata("design:paramtypes", [users_service_1.UsersService])
], UsersController);
//# sourceMappingURL=users.controller.js.map