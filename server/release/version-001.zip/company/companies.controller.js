"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CompaniesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const company_response_1 = require("./responses/company.response");
const company_service_1 = require("./company.service");
let CompaniesController = class CompaniesController {
    companyService;
    constructor(companyService) {
        this.companyService = companyService;
    }
    async getAll(res) {
        let companyNames = await this.companyService.getAllCompanies();
        if (companyNames.length == 0) {
            res.status(common_1.HttpStatus.NO_CONTENT).send();
        }
        res.status(common_1.HttpStatus.OK).json(companyNames);
    }
};
exports.CompaniesController = CompaniesController;
__decorate([
    (0, common_1.Get)('/'),
    (0, swagger_1.ApiOperation)({ summary: 'Find all companies', description: 'Find all companies stored in PersonalMan.' }),
    (0, swagger_1.ApiOkResponse)({
        description: 'Successfully found companies',
        type: [company_response_1.CompanyResponse],
    }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Successful but no companies in database' }),
    __param(0, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], CompaniesController.prototype, "getAll", null);
exports.CompaniesController = CompaniesController = __decorate([
    (0, common_1.Controller)('companies'),
    __metadata("design:paramtypes", [company_service_1.CompanyService])
], CompaniesController);
//# sourceMappingURL=companies.controller.js.map