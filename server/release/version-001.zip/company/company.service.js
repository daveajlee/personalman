"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CompanyService = void 0;
const common_1 = require("@nestjs/common");
const company_model_1 = require("./models/company.model");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
let CompanyService = class CompanyService {
    companyModel;
    constructor(companyModel) {
        this.companyModel = companyModel;
    }
    save(company) {
        const createdCompany = new this.companyModel(company);
        return createdCompany.save() != null;
    }
    async getAllCompanies() {
        let companyNames = [];
        let companies = await this.companyModel.find().exec();
        companies.forEach(company => companyNames.push(company["name"]));
        return companyNames;
    }
    async getCompany(name) {
        let companies = await this.companyModel.find({ name: name }).exec();
        return companies[0];
    }
    async delete(name) {
        var company = await this.getCompany(name);
        if (company != null) {
            var result = await this.companyModel.deleteOne({ name: company["name"] });
            return result.deletedCount != 0;
        }
        return false;
    }
};
exports.CompanyService = CompanyService;
exports.CompanyService = CompanyService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(company_model_1.Company.name)),
    __metadata("design:paramtypes", [mongoose_2.Model])
], CompanyService);
//# sourceMappingURL=company.service.js.map