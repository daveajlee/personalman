export declare class RegisterCompanyRequest {
    private name;
    private defaultAnnualLeaveInDays;
    private country;
    getCountry(): string;
    getDefaultAnnualLeaveInDays(): number;
    getName(): string;
}
