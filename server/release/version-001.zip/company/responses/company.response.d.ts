export declare class CompanyResponse {
    private name;
    private defaultAnnualLeaveInDays;
    private country;
    constructor(name: string, defaultAnnualLeaveInDays: number, country: string);
}
