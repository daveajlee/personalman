import mongoose from "mongoose";
export declare const CompanySchema: mongoose.Schema<any, mongoose.Model<any, any, any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    name?: string | null | undefined;
    defaultAnnualLeaveInDays?: number | null | undefined;
    country?: string | null | undefined;
}, mongoose.Document<unknown, {}, {
    name?: string | null | undefined;
    defaultAnnualLeaveInDays?: number | null | undefined;
    country?: string | null | undefined;
}, {
    id: string;
}, mongoose.DefaultSchemaOptions> & Omit<{
    name?: string | null | undefined;
    defaultAnnualLeaveInDays?: number | null | undefined;
    country?: string | null | undefined;
} & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}, "id"> & {
    id: string;
}, unknown, {
    name?: string | null | undefined;
    defaultAnnualLeaveInDays?: number | null | undefined;
    country?: string | null | undefined;
} & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}>;
