import { RegisterCompanyRequest } from './requests/registercompany.request';
import type { Response } from 'express';
import { CompanyService } from './company.service';
export declare class CompanyController {
    private readonly companyService;
    constructor(companyService: CompanyService);
    retrieve(name: string, token: string, res: Response): Promise<void>;
    add(registerCompanyRequest: RegisterCompanyRequest, res: Response): void;
    delete(name: string, token: string, res: Response): Promise<void>;
    private validateAndAuthenticateRequest;
}
