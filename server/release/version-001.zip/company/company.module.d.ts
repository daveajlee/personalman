export declare class CompanyModule {
}
