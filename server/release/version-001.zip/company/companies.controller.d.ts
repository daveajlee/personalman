import type { Response } from 'express';
import { CompanyService } from './company.service';
export declare class CompaniesController {
    private readonly companyService;
    constructor(companyService: CompanyService);
    getAll(res: Response): Promise<void>;
}
