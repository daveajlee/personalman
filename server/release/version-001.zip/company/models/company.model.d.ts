export declare class Company {
    private name;
    private defaultAnnualLeaveInDays;
    private country;
    constructor(name: string, defaultAnnualLeaveInDays: number, country: string);
    getDefaultAnnualLeaveInDays(): number;
    getName(): string;
    getCountry(): string;
}
