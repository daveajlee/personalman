"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Company = void 0;
class Company {
    name;
    defaultAnnualLeaveInDays;
    country;
    constructor(name, defaultAnnualLeaveInDays, country) {
        this.name = name;
        this.defaultAnnualLeaveInDays = defaultAnnualLeaveInDays;
        this.country = country;
    }
    getDefaultAnnualLeaveInDays() {
        return this.defaultAnnualLeaveInDays;
    }
    getName() {
        return this.name;
    }
    getCountry() {
        return this.country;
    }
}
exports.Company = Company;
//# sourceMappingURL=company.model.js.map