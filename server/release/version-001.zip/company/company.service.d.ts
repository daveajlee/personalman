import { Company } from './models/company.model';
import { Model } from 'mongoose';
export declare class CompanyService {
    private companyModel;
    constructor(companyModel: Model<Company>);
    save(company: Company): boolean;
    getAllCompanies(): Promise<string[]>;
    getCompany(name: string): Promise<Company>;
    delete(name: string): Promise<boolean>;
}
