"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CompanyController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const company_response_1 = require("./responses/company.response");
const registercompany_request_1 = require("./requests/registercompany.request");
const company_service_1 = require("./company.service");
const company_model_1 = require("./models/company.model");
let CompanyController = class CompanyController {
    companyService;
    constructor(companyService) {
        this.companyService = companyService;
    }
    async retrieve(name, token, res) {
        var status = this.validateAndAuthenticateRequest(name, token, res);
        if (status != null && status.statusCode != 200) {
            res.status(status.statusCode).send();
        }
        else {
            var company = await this.companyService.getCompany(name);
            if (company != null) {
                res.status(common_1.HttpStatus.OK).json(new company_response_1.CompanyResponse(company["name"], company["defaultAnnualLeaveInDays"], company["country"]));
            }
            else {
                res.status(common_1.HttpStatus.NOT_FOUND).send();
            }
        }
    }
    add(registerCompanyRequest, res) {
        console.log(registerCompanyRequest);
        console.log(typeof registerCompanyRequest);
        this.companyService.save(new company_model_1.Company(registerCompanyRequest.getName(), registerCompanyRequest.getDefaultAnnualLeaveInDays(), registerCompanyRequest.getCountry()));
        res.status(common_1.HttpStatus.CREATED).send();
    }
    async delete(name, token, res) {
        var status = this.validateAndAuthenticateRequest(name, token, res);
        if (status != null && status.statusCode != 200) {
            res.status(status.statusCode).send();
        }
        else {
            if (await this.companyService.delete(name)) {
                res.status(common_1.HttpStatus.OK).send();
            }
            else {
                res.status(common_1.HttpStatus.NOT_FOUND).send();
            }
        }
    }
    validateAndAuthenticateRequest(name, token, res) {
        if (name === '') {
            res.status(common_1.HttpStatus.BAD_REQUEST).send();
        }
        return res;
    }
};
exports.CompanyController = CompanyController;
__decorate([
    (0, common_1.Get)('/'),
    (0, swagger_1.ApiOperation)({ summary: 'Retrieve a company', description: 'Retrieve a company from the system.' }),
    (0, swagger_1.ApiOkResponse)({
        description: 'Successfully retrieved company details',
        type: company_response_1.CompanyResponse
    }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Company not found' }),
    __param(0, (0, common_1.Query)('name')),
    __param(1, (0, common_1.Query)('token')),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], CompanyController.prototype, "retrieve", null);
__decorate([
    (0, common_1.Post)('/'),
    (0, swagger_1.ApiOperation)({ summary: 'Add a company', description: 'Add a company to the system.' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'Successfully created company' }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [registercompany_request_1.RegisterCompanyRequest, Object]),
    __metadata("design:returntype", void 0)
], CompanyController.prototype, "add", null);
__decorate([
    (0, common_1.Delete)('/'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete a company', description: 'Delete a company from the system.' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully deleted company' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Company not found' }),
    __param(0, (0, common_1.Query)('name')),
    __param(1, (0, common_1.Query)('token')),
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], CompanyController.prototype, "delete", null);
__decorate([
    __param(2, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Object)
], CompanyController.prototype, "validateAndAuthenticateRequest", null);
exports.CompanyController = CompanyController = __decorate([
    (0, common_1.Controller)('company'),
    __metadata("design:paramtypes", [company_service_1.CompanyService])
], CompanyController);
//# sourceMappingURL=company.controller.js.map