export declare class AbsencesModule {
}
