import { AbsenceRequest } from './requests/absence.request';
import { AbsencesService } from './absences.service';
import type { Response } from 'express';
import { UsersService } from "../users/users.service";
export declare class AbsencesController {
    private readonly absenceService;
    private readonly userService;
    constructor(absenceService: AbsencesService, userService: UsersService);
    findOrCount(company: string, startDate: string, endDate: string, token: string, res: Response, username?: string, onlyCount?: string, category?: string): Promise<void>;
    add(absenceRequest: AbsenceRequest, res: Response): Promise<void>;
    convertToDate(date: string): Date;
    delete(company: string, startDate: string, endDate: string, token: string, res: Response, username?: string): Promise<void>;
    private validateAndAuthenticateRequest;
    private prepareAbsencesResponse;
}
