"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AbsenceSchema = void 0;
const mongoose_1 = __importDefault(require("mongoose"));
exports.AbsenceSchema = new mongoose_1.default.Schema({
    category: String,
    company: String,
    username: String,
    startDate: String,
    endDate: String
});
//# sourceMappingURL=absence.schema.js.map