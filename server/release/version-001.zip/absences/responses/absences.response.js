"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AbsencesResponse = void 0;
const swagger_1 = require("@nestjs/swagger");
const absence_response_1 = require("./absence.response");
class AbsencesResponse {
    count;
    absenceResponseList;
    statisticsMap;
    constructor(statisticsMap) {
        this.statisticsMap = statisticsMap;
    }
    setCount(count) {
        this.count = count;
    }
    setAbsenceResponseList(absenceResponseList) {
        this.absenceResponseList = absenceResponseList;
    }
    getAbsenceResponseList() {
        return this.absenceResponseList;
    }
    addToStatisticsMap(category, days) {
        this.statisticsMap.set(category, days);
    }
}
exports.AbsencesResponse = AbsencesResponse;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], AbsencesResponse.prototype, "count", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [absence_response_1.AbsenceResponse] }),
    __metadata("design:type", Array)
], AbsencesResponse.prototype, "absenceResponseList", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Map)
], AbsencesResponse.prototype, "statisticsMap", void 0);
//# sourceMappingURL=absences.response.js.map