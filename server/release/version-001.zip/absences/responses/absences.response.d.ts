import { AbsenceResponse } from "./absence.response";
export declare class AbsencesResponse {
    private count;
    private absenceResponseList;
    private statisticsMap;
    constructor(statisticsMap: Map<string, number>);
    setCount(count: number): void;
    setAbsenceResponseList(absenceResponseList: AbsenceResponse[]): void;
    getAbsenceResponseList(): AbsenceResponse[];
    addToStatisticsMap(category: string, days: number): void;
}
