export declare class AbsenceResponse {
    private company;
    private username;
    private startDate;
    private endDate;
    private category;
    constructor(company: string, username: string, startDate: string, endDate: string, category: string);
    getCompany(): string;
    getUsername(): string;
    getStartDate(): string;
    getEndDate(): string;
    getCategory(): string;
    setCategory(category: string): void;
}
