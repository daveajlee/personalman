import mongoose from "mongoose";
export declare const AbsenceSchema: mongoose.Schema<any, mongoose.Model<any, any, any, any, any, any, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, {
    company?: string | null | undefined;
    startDate?: string | null | undefined;
    endDate?: string | null | undefined;
    username?: string | null | undefined;
    category?: string | null | undefined;
}, mongoose.Document<unknown, {}, {
    company?: string | null | undefined;
    startDate?: string | null | undefined;
    endDate?: string | null | undefined;
    username?: string | null | undefined;
    category?: string | null | undefined;
}, {
    id: string;
}, mongoose.DefaultSchemaOptions> & Omit<{
    company?: string | null | undefined;
    startDate?: string | null | undefined;
    endDate?: string | null | undefined;
    username?: string | null | undefined;
    category?: string | null | undefined;
} & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}, "id"> & {
    id: string;
}, unknown, {
    company?: string | null | undefined;
    startDate?: string | null | undefined;
    endDate?: string | null | undefined;
    username?: string | null | undefined;
    category?: string | null | undefined;
} & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}>;
