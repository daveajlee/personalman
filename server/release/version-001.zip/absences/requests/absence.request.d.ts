export declare class AbsenceRequest {
    private company;
    private username;
    private startDate;
    private endDate;
    private category;
    private token;
    getStartDate(): string;
    getEndDate(): string;
    getCompany(): string;
    getCategory(): string;
    getUsername(): string;
    getToken(): string;
}
