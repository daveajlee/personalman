"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AbsenceCategory = void 0;
var AbsenceCategory;
(function (AbsenceCategory) {
    AbsenceCategory["ILLNESS"] = "Illness";
    AbsenceCategory["HOLIDAY"] = "Holiday";
    AbsenceCategory["TRIP"] = "Trip";
    AbsenceCategory["CONFERENCE"] = "Conference";
    AbsenceCategory["DAY_IN_LIEU"] = "Day in Lieu";
    AbsenceCategory["DAY_IN_LIEU_REQUEST"] = "Day in Lieu Request";
    AbsenceCategory["FEDERAL_HOLIDAY"] = "Federal Holiday";
})(AbsenceCategory || (exports.AbsenceCategory = AbsenceCategory = {}));
//# sourceMappingURL=absencecategory.enum.js.map