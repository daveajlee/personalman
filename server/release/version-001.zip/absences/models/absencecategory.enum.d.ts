export declare enum AbsenceCategory {
    ILLNESS = "Illness",
    HOLIDAY = "Holiday",
    TRIP = "Trip",
    CONFERENCE = "Conference",
    DAY_IN_LIEU = "Day in Lieu",
    DAY_IN_LIEU_REQUEST = "Day in Lieu Request",
    FEDERAL_HOLIDAY = "Federal Holiday"
}
