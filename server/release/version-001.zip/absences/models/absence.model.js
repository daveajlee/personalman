"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Absence = void 0;
class Absence {
    category;
    company;
    username;
    startDate;
    endDate;
    constructor(category, company, username, startDate, endDate) {
        this.category = category;
        this.company = company;
        this.username = username;
        this.startDate = startDate;
        this.endDate = endDate;
    }
    getCategory() {
        return this.category;
    }
    getStartDate() {
        return this.startDate;
    }
    getEndDate() {
        return this.endDate;
    }
    getCompany() {
        return this.company;
    }
    getUsername() {
        return this.username;
    }
}
exports.Absence = Absence;
//# sourceMappingURL=absence.model.js.map