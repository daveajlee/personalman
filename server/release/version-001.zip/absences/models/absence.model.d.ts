export declare class Absence {
    private category;
    private company;
    private username;
    private startDate;
    private endDate;
    constructor(category: string, company: string, username: string, startDate: string, endDate: string);
    getCategory(): string;
    getStartDate(): string;
    getEndDate(): string;
    getCompany(): string;
    getUsername(): string;
}
