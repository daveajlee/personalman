import { UsersService } from '../users/users.service';
import { Absence } from './models/absence.model';
import { AbsenceCategory } from './models/absencecategory.enum';
import { Model } from 'mongoose';
export declare class AbsencesService {
    private absenceModel;
    private readonly userService;
    constructor(absenceModel: Model<Absence>, userService: UsersService);
    save(absence: Absence): Promise<boolean>;
    private controlAbsencesForYear;
    findAbsences(company: string, username: string, startDate: Date, endDate: Date): Promise<Absence[]>;
    countAbsences(company: string, username: string, startDate: Date, endDate: Date, absenceCategory: AbsenceCategory | null): Promise<number>;
    delete(company: string, username: string, startDate: Date, endDate: Date): Promise<void>;
    deleteAllForCompany(company: string): Promise<void>;
}
