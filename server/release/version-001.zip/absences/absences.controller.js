"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AbsencesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const absences_response_1 = require("./responses/absences.response");
const absence_request_1 = require("./requests/absence.request");
const absences_service_1 = require("./absences.service");
const absencecategory_enum_1 = require("./models/absencecategory.enum");
const users_service_1 = require("../users/users.service");
const absence_utils_1 = require("./utils/absence.utils");
let AbsencesController = class AbsencesController {
    absenceService;
    userService;
    constructor(absenceService, userService) {
        this.absenceService = absenceService;
        this.userService = userService;
    }
    async findOrCount(company, startDate, endDate, token, res, username, onlyCount, category) {
        var status = this.validateAndAuthenticateRequest(startDate, endDate, token);
        if (status != null) {
            res.status(status).send();
        }
        var absencesResponse = this.prepareAbsencesResponse();
        if (onlyCount === "true") {
            var absenceCategory = null;
            if (category != null) {
                absenceCategory = absence_utils_1.AbsenceUtils.absenceCategoryFromString(category);
            }
            if (absenceCategory == null) {
                res.status(common_1.HttpStatus.BAD_REQUEST).send();
            }
            if (username != null && absenceCategory != null) {
                var count = await this.absenceService.countAbsences(company, username, this.convertToDate(startDate), this.convertToDate(endDate), absenceCategory);
                absencesResponse.setCount(count);
            }
        }
        else if (username != null) {
            var absenceResponses = absence_utils_1.AbsenceUtils.convertAbsencesToAbsenceResponses(await this.absenceService.findAbsences(company, username, this.convertToDate(startDate), this.convertToDate(endDate)));
            absencesResponse.setCount(absenceResponses.length);
            absencesResponse.setAbsenceResponseList(absenceResponses);
            absencesResponse = absence_utils_1.AbsenceUtils.calculateAbsencesResponseStatistics(absencesResponse);
        }
        res.status(common_1.HttpStatus.OK).json(absencesResponse);
    }
    async add(absenceRequest, res) {
        var status = this.validateAndAuthenticateRequest(absenceRequest.getStartDate(), absenceRequest.getEndDate(), absenceRequest.getToken());
        if (status != null) {
            res.send();
        }
        if (absenceRequest.getCategory() === "" || absenceRequest.getCompany() === ""
            || absenceRequest.getEndDate() === "" || absenceRequest.getStartDate() === ""
            || absenceRequest.getUsername() === "") {
            res.status(common_1.HttpStatus.BAD_REQUEST).send();
        }
        var result = await this.absenceService.save(absence_utils_1.AbsenceUtils.convertAbsenceRequestToAbsence(absenceRequest, this.convertToDate(absenceRequest.getStartDate()), this.convertToDate(absenceRequest.getEndDate())));
        result ? res.status(common_1.HttpStatus.CREATED).send() : res.status(common_1.HttpStatus.INTERNAL_SERVER_ERROR).send();
    }
    convertToDate(date) {
        let dateSplit = date.split("-");
        return new Date(parseInt(dateSplit[2]), parseInt(dateSplit[1]) - 1, parseInt(dateSplit[0]));
    }
    async delete(company, startDate, endDate, token, res, username) {
        var status = this.validateAndAuthenticateRequest(startDate, endDate, token);
        if (status != null) {
            res.send();
        }
        else {
            if (username != null) {
                await this.absenceService.delete(company, username, this.convertToDate(startDate), this.convertToDate(endDate));
            }
            res.status(common_1.HttpStatus.OK).send();
        }
    }
    validateAndAuthenticateRequest(startDate, endDate, token) {
        if (startDate === "" || endDate === "" || token === "") {
            return common_1.HttpStatus.BAD_REQUEST;
        }
        var startLocalDate = this.convertToDate(startDate);
        var endLocalDate = this.convertToDate(endDate);
        if (startLocalDate == null || endLocalDate == null || endLocalDate < startLocalDate) {
            return common_1.HttpStatus.BAD_REQUEST;
        }
        if (token == null || !this.userService.checkAuthToken(token)) {
            return common_1.HttpStatus.FORBIDDEN;
        }
        return null;
    }
    prepareAbsencesResponse() {
        let statisticsMap = new Map();
        for (var absenceCategory in absencecategory_enum_1.AbsenceCategory) {
            statisticsMap.set(absenceCategory.toString(), 0);
        }
        return new absences_response_1.AbsencesResponse(statisticsMap);
    }
};
exports.AbsencesController = AbsencesController;
__decorate([
    (0, common_1.Get)('/'),
    (0, swagger_1.ApiQuery)({
        name: 'username',
        type: String,
        description: 'Username',
        required: false,
    }),
    (0, swagger_1.ApiQuery)({
        name: 'onlyCount',
        type: Boolean,
        description: 'Only count absences',
        required: false,
        default: false,
    }),
    (0, swagger_1.ApiQuery)({
        name: 'category',
        type: String,
        description: 'Absence category',
        required: false,
    }),
    (0, swagger_1.ApiOperation)({
        summary: 'Find or count absences',
        description: 'Find or count absences in the system according to the specified criteria.',
    }),
    (0, swagger_1.ApiOkResponse)({
        description: 'Successfully completed the search for absences',
        type: [absences_response_1.AbsencesResponse],
    }),
    __param(0, (0, common_1.Query)('company')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __param(3, (0, common_1.Query)('token')),
    __param(4, (0, common_1.Res)()),
    __param(5, (0, common_1.Query)('username')),
    __param(6, (0, common_1.Query)('onlyCount')),
    __param(7, (0, common_1.Query)('category')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, Object, String, String, String]),
    __metadata("design:returntype", Promise)
], AbsencesController.prototype, "findOrCount", null);
__decorate([
    (0, common_1.Post)('/'),
    (0, swagger_1.ApiOperation)({
        summary: 'Add an absence',
        description: 'Add an absence to the system.',
    }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'Successfully created absence' }),
    __param(0, (0, common_1.Body)(new common_1.ValidationPipe({ transform: true }))),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [absence_request_1.AbsenceRequest, Object]),
    __metadata("design:returntype", Promise)
], AbsencesController.prototype, "add", null);
__decorate([
    (0, common_1.Delete)('/'),
    (0, swagger_1.ApiOperation)({
        summary: 'Delete absences',
        description: 'Delete absences in the system according to the specified criteria.',
    }),
    (0, swagger_1.ApiQuery)({
        name: 'username',
        type: String,
        description: 'Username',
        required: false,
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully deleted absences' }),
    __param(0, (0, common_1.Query)('company')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __param(3, (0, common_1.Query)('token')),
    __param(4, (0, common_1.Res)()),
    __param(5, (0, common_1.Query)('username')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, Object, String]),
    __metadata("design:returntype", Promise)
], AbsencesController.prototype, "delete", null);
exports.AbsencesController = AbsencesController = __decorate([
    (0, common_1.Controller)('absences'),
    __metadata("design:paramtypes", [absences_service_1.AbsencesService, users_service_1.UsersService])
], AbsencesController);
//# sourceMappingURL=absences.controller.js.map