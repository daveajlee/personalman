import { Absence } from "../models/absence.model";
import { AbsenceRequest } from "../requests/absence.request";
import { AbsenceResponse } from "../responses/absence.response";
import { AbsenceCategory } from "../models/absencecategory.enum";
import { AbsencesResponse } from "../responses/absences.response";
import { User } from "../../users/models/user.model";
export declare class AbsenceUtils {
    static convertAbsenceRequestToAbsence(absenceRequest: AbsenceRequest, startDate: Date, endDate: Date): Absence;
    static absenceCategoryFromString(category: string): AbsenceCategory | null;
    static convertAbsencesToAbsenceResponses(absences: Absence[]): AbsenceResponse[];
    static calculateAbsencesResponseStatistics(absencesResponse: AbsencesResponse): AbsencesResponse;
    static countAbsencesInDays(absences: Absence[]): number;
    static generateAbsences(user: User, startDate: Date, endDate: Date, category: AbsenceCategory | null): Absence[];
    static getDayOfWeekNumber(day: string): 0 | 1 | 2 | 3 | 4 | 5 | 6;
    static generateDaysInLieu(user: User, startDate: Date, endDate: Date): Absence[];
}
