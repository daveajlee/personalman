"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AbsenceUtils = void 0;
const absence_model_1 = require("../models/absence.model");
const absence_response_1 = require("../responses/absence.response");
const absencecategory_enum_1 = require("../models/absencecategory.enum");
class AbsenceUtils {
    static convertAbsenceRequestToAbsence(absenceRequest, startDate, endDate) {
        return new absence_model_1.Absence(absenceRequest.getCategory(), absenceRequest.getCompany(), absenceRequest.getUsername(), startDate.toDateString(), endDate.toDateString());
    }
    static absenceCategoryFromString(category) {
        switch (category) {
            case "Conference":
                return absencecategory_enum_1.AbsenceCategory.CONFERENCE;
            case "Day in Lieu":
                return absencecategory_enum_1.AbsenceCategory.DAY_IN_LIEU;
            case "Day in Lieu Request":
                return absencecategory_enum_1.AbsenceCategory.DAY_IN_LIEU_REQUEST;
            case "Federal Holiday":
                return absencecategory_enum_1.AbsenceCategory.FEDERAL_HOLIDAY;
            case "Holiday":
                return absencecategory_enum_1.AbsenceCategory.HOLIDAY;
            case "Illness":
                return absencecategory_enum_1.AbsenceCategory.ILLNESS;
            case "Trip":
                return absencecategory_enum_1.AbsenceCategory.TRIP;
            default:
                return null;
        }
    }
    static convertAbsencesToAbsenceResponses(absences) {
        let absenceResponses = [];
        absences.forEach((absence) => {
            let absenceResponse = new absence_response_1.AbsenceResponse("", absence["company"], absence["username"], absence["startDate"], absence["endDate"]);
            if (absence["category"] != null) {
                absenceResponse.setCategory(absence["category"]);
            }
            absenceResponses.push(absenceResponse);
        });
        return absenceResponses;
    }
    static calculateAbsencesResponseStatistics(absencesResponse) {
        let absenceResponseList = absencesResponse.getAbsenceResponseList();
        absenceResponseList.forEach((absenceResponse) => {
            if (absenceResponse.getStartDate() != null && absenceResponse.getEndDate() != null
                && absenceResponse.getCategory() != null) {
                absencesResponse.addToStatisticsMap(absenceResponse.getCategory(), (new Date(absenceResponse.getStartDate()).getDate() - new Date(absenceResponse.getEndDate()).getDate()) + 1);
            }
        });
        return absencesResponse;
    }
    static countAbsencesInDays(absences) {
        let numAbsentDays = 0;
        absences.forEach((absence) => {
            numAbsentDays += (new Date(absence.getStartDate()).getDate() - new Date(absence.getEndDate()).getDate()) + 1;
        });
        return numAbsentDays;
    }
    static generateAbsences(user, startDate, endDate, category) {
        let workingDays = user["workingDays"];
        let absences = [];
        let currentDate = startDate;
        while (currentDate.getTime() <= endDate.getTime()) {
            let isFreeDay = true;
            workingDays.forEach((workingDay) => {
                if (this.getDayOfWeekNumber(workingDay) == currentDate.getDay()) {
                    isFreeDay = false;
                }
            });
            if (!isFreeDay) {
                absences.push(new absence_model_1.Absence(category?.valueOf() != undefined ? category?.valueOf() : "", user["company"], user["userName"], currentDate.toDateString(), currentDate.toDateString()));
            }
            currentDate.setDate(currentDate.getDate() + 1);
        }
        return absences;
    }
    static getDayOfWeekNumber(day) {
        switch (day) {
            case 'Sunday':
                return 0;
            case 'Monday':
                return 1;
            case 'Tuesday':
                return 2;
            case 'Wednesday':
                return 3;
            case 'Thursday':
                return 4;
            case 'Friday':
                return 5;
            default:
                return 6;
        }
    }
    static generateDaysInLieu(user, startDate, endDate) {
        let workingDays = user.getWorkingDays();
        let absences = [];
        let actualDate = startDate;
        while (actualDate.getTime() <= endDate.getTime()) {
            let isFreeDay = true;
            workingDays.forEach((workingDay) => {
                if (parseInt(workingDay) == actualDate.getDay()) {
                    isFreeDay = false;
                }
            });
            if (isFreeDay) {
                absences.push(new absence_model_1.Absence(absencecategory_enum_1.AbsenceCategory.DAY_IN_LIEU_REQUEST, user.getCompany(), user.getUsername(), actualDate.toDateString(), actualDate.toDateString()));
            }
            actualDate.setDate(actualDate.getDate() + 1);
        }
        return absences;
    }
}
exports.AbsenceUtils = AbsenceUtils;
//# sourceMappingURL=absence.utils.js.map