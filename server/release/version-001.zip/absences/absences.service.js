"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AbsencesService = void 0;
const common_1 = require("@nestjs/common");
const users_service_1 = require("../users/users.service");
const absence_model_1 = require("./models/absence.model");
const absencecategory_enum_1 = require("./models/absencecategory.enum");
const absence_utils_1 = require("./utils/absence.utils");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
let AbsencesService = class AbsencesService {
    absenceModel;
    userService;
    constructor(absenceModel, userService) {
        this.absenceModel = absenceModel;
        this.userService = userService;
    }
    async save(absence) {
        let result = true;
        let user = await this.userService.findByCompanyAndUserName(absence.getCompany(), absence.getUsername());
        let absences = [];
        if (absence.getCategory() === "Holiday" && user != null) {
            var absenceEndDate = new Date(absence.getEndDate());
            absenceEndDate.setDate(absenceEndDate.getDate() + 1);
            if (Math.abs(new Date(absence.getStartDate()).getFullYear() - absenceEndDate.getFullYear()) < 2) {
                absences = absences.concat(absence_utils_1.AbsenceUtils.generateAbsences(user, new Date(absence.getStartDate()), absenceEndDate, absence_utils_1.AbsenceUtils.absenceCategoryFromString(absence.getCategory())));
                result = await this.controlAbsencesForYear(absence.getCompany(), absence.getUsername(), new Date(absence.getStartDate()).getFullYear(), absence_utils_1.AbsenceUtils.absenceCategoryFromString(absence.getCategory()), user, absences);
            }
            else if (new Date(absence.getStartDate()).getFullYear() == new Date(absence.getEndDate()).getFullYear()) {
                absences = absences.concat(absence_utils_1.AbsenceUtils.generateAbsences(user, new Date(absence.getStartDate()), new Date(absence.getEndDate()), absence_utils_1.AbsenceUtils.absenceCategoryFromString(absence.getCategory())));
                result = await this.controlAbsencesForYear(absence.getCompany(), absence.getUsername(), new Date(absence.getStartDate()).getFullYear(), absence_utils_1.AbsenceUtils.absenceCategoryFromString(absence.getCategory()), user, absences);
            }
            else {
                result = false;
            }
        }
        else if ((absence.getCategory() == absencecategory_enum_1.AbsenceCategory.CONFERENCE || absence.getCategory() == absencecategory_enum_1.AbsenceCategory.TRIP) && user != null) {
            let newAbsence = new absence_model_1.Absence(absence.getCategory(), absence.getCompany(), absence.getUsername(), absence.getStartDate(), absence.getEndDate());
            absences.push(newAbsence);
            absences.concat(absence_utils_1.AbsenceUtils.generateDaysInLieu(user, new Date(absence.getStartDate()), new Date(absence.getEndDate())));
        }
        else if (absence.getCategory() == absencecategory_enum_1.AbsenceCategory.DAY_IN_LIEU && user != null) {
            if (new Date(absence.getStartDate()).getFullYear() != new Date(absence.getEndDate()).getFullYear()) {
                result = false;
            }
            else {
                var numDayInLieuDaysRequests = await this.countAbsences(absence.getCompany(), absence.getUsername(), new Date(new Date(absence.getStartDate()).getFullYear(), 1, 1), new Date(new Date(absence.getStartDate()).getFullYear(), 12, 31), absencecategory_enum_1.AbsenceCategory.DAY_IN_LIEU_REQUEST);
                var numDayInLieuDays = await this.countAbsences(absence.getCompany(), absence.getUsername(), new Date(new Date(absence.getStartDate()).getFullYear(), 1, 1), new Date(new Date(absence.getStartDate()).getFullYear(), 12, 31), absencecategory_enum_1.AbsenceCategory.DAY_IN_LIEU);
                var numDayInLieuDaysAvailable = numDayInLieuDaysRequests - numDayInLieuDays;
                var numDaysDesired = Math.abs(new Date(absence.getStartDate()).getDate() - Math.abs(new Date(absence.getEndDate()).getDate())) + 1;
                result = numDaysDesired <= numDayInLieuDaysAvailable;
                absences.concat(absence_utils_1.AbsenceUtils.generateAbsences(user, new Date(absence.getStartDate()), new Date(absence.getEndDate()), absence_utils_1.AbsenceUtils.absenceCategoryFromString(absence.getCategory())));
            }
        }
        else if (user != null) {
            absences.concat(absence_utils_1.AbsenceUtils.generateAbsences(user, new Date(absence.getStartDate()), new Date(absence.getEndDate()), absence_utils_1.AbsenceUtils.absenceCategoryFromString(absence.getCategory())));
        }
        if (result) {
            for (var i = 0; i < absences.length; i++) {
                const createdAbsence = new this.absenceModel(absences[i]);
                await createdAbsence.save();
            }
        }
        return result;
    }
    async controlAbsencesForYear(company, employeeName, year, category, user, absences) {
        var numAnnualLeave = await this.countAbsences(company, employeeName, new Date(year, 1, 1), new Date(year, 12, 31), category);
        numAnnualLeave += absence_utils_1.AbsenceUtils.countAbsencesInDays(absences);
        if (user) {
            return numAnnualLeave <= user["leaveEntitlementPerYear"];
        }
        return false;
    }
    async findAbsences(company, username, startDate, endDate) {
        return await this.absenceModel.find({ company: company, username: username }).exec();
    }
    async countAbsences(company, username, startDate, endDate, absenceCategory) {
        var count = 0;
        var matchingAbsences = await this.findAbsences(company, username, startDate, endDate);
        for (var i = 0; i < matchingAbsences.length; i++) {
            var matchingAbsence = matchingAbsences[i];
            if (matchingAbsence.getCategory() == absenceCategory) {
                count = (new Date(matchingAbsence.getEndDate()).getDay() - new Date(matchingAbsence.getStartDate()).getDay()) + 1;
            }
        }
        return count;
    }
    async delete(company, username, startDate, endDate) {
        var absencesToDelete = await this.findAbsences(company, username, startDate, endDate);
        for (var i = 0; i < absencesToDelete.length; i++) {
            await this.absenceModel.deleteOne(absencesToDelete[i]);
        }
    }
    async deleteAllForCompany(company) {
        var absencesToDelete = await this.absenceModel.find({ company: company }).exec();
        absencesToDelete.forEach((absence) => {
            this.absenceModel.deleteOne(absence);
        });
    }
};
exports.AbsencesService = AbsencesService;
exports.AbsencesService = AbsencesService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, mongoose_1.InjectModel)(absence_model_1.Absence.name)),
    __metadata("design:paramtypes", [mongoose_2.Model, users_service_1.UsersService])
], AbsencesService);
//# sourceMappingURL=absences.service.js.map